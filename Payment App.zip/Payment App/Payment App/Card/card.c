#ifndef card
    #include "card.h"
#endif // card

EN_cardError_t getCardHolderName(ST_cardData_t* cardData) {
	printf("Card Holder's Name:\n\t\t");
	//scanf("%s",cardData->cardHolderName);
	gets(cardData->cardHolderName);
    if(strlen(cardData->cardHolderName)<20 || (strlen(cardData->cardHolderName)>24)){
        return WRONG_NAME;
    }
    else{
        return CARD_OK;
    }
}//end getCardHolderName

EN_cardError_t getCardExpiryDate(ST_cardData_t* cardData){
    printf("Card Expiry Date \"MM/YY\":\n\t\t");
	gets(cardData->cardExpirationDate);
    if(cardData->cardExpirationDate[2] != '/'  || cardData->cardExpirationDate == NULL
       || str2num(cardData->cardExpirationDate[0]) > 1){
        return WRONG_EXP_DATE;
    }else if(str2num(cardData->cardExpirationDate[0]) == 1 && str2num(cardData->cardExpirationDate[1]) > 2){
        return WRONG_EXP_DATE;
    }else{
        return CARD_OK;
    }
}//end getCardExpiryDate

EN_cardError_t getCardPAN(ST_cardData_t* cardData){

    printf("Primary Account Number(PAN):\n\t\t");
	gets(cardData->primaryAccountNumber);

	for(int i =0; i<strlen(cardData->primaryAccountNumber); i++){
        if(str2num(cardData->primaryAccountNumber[i]) > 9
           || str2num(cardData->primaryAccountNumber[i]) < 0)
           {
                return WRONG_PAN;
           }
	}

	if(strlen(cardData->primaryAccountNumber) < 16
    || strlen(cardData->primaryAccountNumber) > 19 )
    {
        return WRONG_PAN;
    }else{
        return CARD_OK;
    }
}//end getCardPAN
