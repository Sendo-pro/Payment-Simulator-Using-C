#ifndef server
    #include "server.h"
#endif // server

#define Accounts_NUM 6
    extern ST_accountsDB_t accountsDB[255] = {
    {100000.0, BLOCKED, "5807007076043875"},
     {2000.0, RUNNING, "8989374615436851"},
     {25000.0, RUNNING, "8989383215436851"},
     {5000.0, BLOCKED, "123456789987654321"},
     {900.0 , RUNNING, "15975368420095874"},
     {9500000.0, RUNNING, "357412689025468325"}
    };

    extern ST_transaction_t transactionsDB[255] = {0};      //needs verification and improvement
    extern int SequenceNumber =-1;

    EN_transState_t recieveTransactionData(ST_transaction_t *transData)
    {
        /*looking for the PAN in accountsDB*/
        signed short int found = -1;
        for(short int i = 0; i<Accounts_NUM; i++){
            if(!strcmp(transData->cardHolderData.primaryAccountNumber , accountsDB[i].primaryAccountNumber)){
                found =i;break;
            }
        }//end for

        if (found == -1){transData->transState = FRAUD_CARD;saveTransaction(transData);return FRAUD_CARD;}  //Not found in accountsDB
        else if(accountsDB[found].state == BLOCKED){transData->transState = DECLINED_STOLEN_CARD; saveTransaction(transData);return DECLINED_STOLEN_CARD;}
        else if(accountsDB[found].balance < transData->terminalData.transAmount){transData->transState = DECLINED_INSUFFECIENT_FUND;saveTransaction(transData);return DECLINED_INSUFFECIENT_FUND;}
        else if(SequenceNumber >= 254){transData->transState =INTERNAL_SERVER_ERROR;saveTransaction(transData);return INTERNAL_SERVER_ERROR;}      //needs Improvement
        else{
                accountsDB[found].balance -= transData->terminalData.transAmount;
                transData->transState = APPROVED;
                saveTransaction(transData);
                return APPROVED;}


    }

    EN_serverError_t isValidAccount(ST_cardData_t *cardData, ST_accountsDB_t *accountRefrence)
    {
        short int found = -1;
        for(short int i = 0; i<Accounts_NUM; i++){
            if(!strcmp(cardData->primaryAccountNumber , accountsDB[i].primaryAccountNumber)){
                found =i;break;
            }
        }//end for
        if (found == -1){return ACCOUNT_NOT_FOUND;}
        else{*accountRefrence = accountsDB[found];return SERVER_OK;}
    }

    EN_serverError_t isBlockedAccount(ST_accountsDB_t *accountRefrence)
    {
        if(accountRefrence->state == BLOCKED){return BLOCKED_ACCOUNT;}
            else{return SERVER_OK;}
    }

    EN_serverError_t isAmountAvailable(ST_terminalData_t *termData,  ST_accountsDB_t *accountRefrence)
    {
        if(termData->transAmount > accountRefrence->balance){return LOW_BALANCE;}
        else{return SERVER_OK;}
    }

    EN_serverError_t saveTransaction(ST_transaction_t *transData)
    {
        if(SequenceNumber <254){
        SequenceNumber++;
        transData->transactionSequenceNumber = SequenceNumber;
        strcpy(transactionsDB[SequenceNumber].cardHolderData.cardExpirationDate , transData->cardHolderData.cardExpirationDate);
        strcpy(transactionsDB[SequenceNumber].cardHolderData.cardHolderName , transData->cardHolderData.cardHolderName);
        strcpy(transactionsDB[SequenceNumber].cardHolderData.primaryAccountNumber , transData->cardHolderData.primaryAccountNumber);
        transactionsDB[SequenceNumber].terminalData.maxTransAmount = transData->terminalData.maxTransAmount;
        strcpy(transactionsDB[SequenceNumber].terminalData.transactionDate , transData->terminalData.transactionDate);
        transactionsDB[SequenceNumber].terminalData.transAmount = transData->terminalData.transAmount;
        transactionsDB[SequenceNumber].transactionSequenceNumber = transData->transactionSequenceNumber;
        transactionsDB[SequenceNumber].transState = transData->transState;
         return SERVER_OK;
        }else{
         return SAVING_FAILED;
        }

    }

    EN_serverError_t getTransaction(uint32_t transactionSequenceNumber, ST_transaction_t *transData)
    {
        int found = -1;
        if(SequenceNumber <255 && SequenceNumber >0){
            for(int i = 0; i< 255; i++){if(transactionSequenceNumber == transactionsDB[i].transactionSequenceNumber){found = 1;break;}}
            if(found == 1){
            strcpy( transData->cardHolderData.cardExpirationDate,transactionsDB[transactionSequenceNumber].cardHolderData.cardExpirationDate );
            strcpy( transData->cardHolderData.cardHolderName,transactionsDB[transactionSequenceNumber].cardHolderData.cardHolderName );
            strcpy( transData->cardHolderData.primaryAccountNumber, transactionsDB[transactionSequenceNumber].cardHolderData.primaryAccountNumber);
            transData->terminalData.maxTransAmount = transactionsDB[transactionSequenceNumber].terminalData.maxTransAmount;
            strcpy( transData->terminalData.transactionDate,transactionsDB[transactionSequenceNumber].terminalData.transactionDate );
            transData->terminalData.transAmount = transactionsDB[transactionSequenceNumber].terminalData.transAmount;
            transData->transState = transactionsDB[transactionSequenceNumber].transState;
            return SERVER_OK;
            }
            else{
            return TRANSACTION_NOT_FOUND;
            }

        }else{
            return TRANSACTION_NOT_FOUND;
        }
    }

/*
        int prntTransData(int transactionSequenceNumber){
        if(transactionSequenceNumber <= SequenceNumber){
        printf("\nTransaction Sequence Number %d\n",transactionSequenceNumber);
        puts("Card Holder Data:\n");
        printf("Card Holder Name: %s\n",transactionsDB[transactionSequenceNumber].cardHolderData.cardHolderName);
        printf("primary Account Number: %s\n",transactionsDB[transactionSequenceNumber].cardHolderData.primaryAccountNumber);
        printf("Card Expiration Date: %s\n",transactionsDB[transactionSequenceNumber].cardHolderData.cardExpirationDate);

        puts("\nTerminal Data:\n");
        printf("Transaction Date: %s \n",transactionsDB[transactionSequenceNumber].terminalData.transactionDate);
        printf("Maximum Transaction Amount: %f \n",transactionsDB[transactionSequenceNumber].terminalData.maxTransAmount);
        printf("Transaction Amount: %f \n",transactionsDB[transactionSequenceNumber].terminalData.transAmount);

        printf("Transaction State:");
        printf("%d",transactionsDB[transactionSequenceNumber].transState);
        return 0;
        }else{
            return -1;
        }
        }

*/
