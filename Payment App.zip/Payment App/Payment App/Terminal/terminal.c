#ifndef terminal
    #include "terminal.h"
#endif // terminal
EN_terminalError_t getTransactionDate(ST_terminalData_t *termData){
    printf("\nTransaction Date:\n\t\t");
    gets(termData->transactionDate);

    for(int i =0; i<strlen(termData->transactionDate); i++){
        if(i==2 || i==5){continue;}
        if(str2num(termData->transactionDate[i]) > 9
           || str2num(termData->transactionDate[i]) < 0)
           {
                return WRONG_DATE;
           }
	}

    if(termData->transactionDate == NULL || strlen(termData->transactionDate) <10){
        return WRONG_DATE;
    }else if(termData->transactionDate[2] != '/'
             || termData->transactionDate[5]!= '/')
     {
         return WRONG_DATE;
     }else{
        return TERMINAL_OK;
     }
}

EN_terminalError_t isCardExpired(ST_cardData_t *cardData, ST_terminalData_t *termData)
{
    uint8_t arr1[] = {cardData->cardExpirationDate[3],cardData->cardExpirationDate[4]};
    uint8_t arr2[] = {termData->transactionDate[8],termData->transactionDate[9]};
    int temp1 = strcmp(arr1,arr2);

    uint8_t arr3[] = {cardData->cardExpirationDate[0],cardData->cardExpirationDate[1]};
    uint8_t arr4[] = {termData->transactionDate[3],termData->transactionDate[4]};
    int temp2 = strcmp(arr3,arr4);


    if(temp1 > 0){return TERMINAL_OK;}
    else if(temp1<0){return EXPIRED_CARD;}
    else{
        if(temp2 > 0){return TERMINAL_OK;}
        else if(temp2<0){return EXPIRED_CARD;}
        else{
            return TERMINAL_OK;     // =
        }
    }
}

//EN_terminalError_t isValidCardPAN(ST_cardData_t *cardData){}

EN_terminalError_t getTransactionAmount(ST_terminalData_t *termData)
{
    printf("\nTransaction Amount:\n\t\t");
    scanf("%f",&(termData->transAmount));
    if(termData->transAmount <= 0){
        return INVALID_AMOUNT;
    }else{
        return TERMINAL_OK;
    }
}

EN_terminalError_t setMaxAmount(ST_terminalData_t *termData){
    printf("\nMaximum Terminal Amount:\n\t\t");
    scanf("%f",&termData->maxTransAmount);
    if(termData->maxTransAmount <= 0){
        return INVALID_MAX_AMOUNT;
    }else{
        return TERMINAL_OK;
    }
}


EN_terminalError_t isBelowMaxAmount(ST_terminalData_t *termData)
{
    if(termData->maxTransAmount < termData->transAmount){
        return EXCEED_MAX_AMOUNT;
    }else{return TERMINAL_OK;}
}

