#ifndef app
    #include "app.h"
#endif // app

//Declaring Variables
ST_cardData_t cardData;
EN_cardError_t cardERROR;

ST_terminalData_t terminalData;
EN_terminalError_t dateERROR , amountERROR;

ST_transaction_t transDATA;
EN_transState_t transERROR;

ST_accountsDB_t accountRefrence;
EN_serverError_t serverERROR;

void appStart(void){
int temp = -1;
    /********   CARD   ************/
    Re_Enter_Name: cardERROR = getCardHolderName(&cardData);
    if(cardERROR == WRONG_NAME){puts("\nWrong Name\n");goto Re_Enter_Name;}

    Re_EXP_DATE: cardERROR = getCardExpiryDate(&cardData);
    if(cardERROR == WRONG_EXP_DATE){puts("\nWrong Card Expiry Date\n");goto Re_EXP_DATE;}

    Re_ENTER_PAN: cardERROR = getCardPAN(&cardData);
    if(cardERROR == WRONG_PAN){puts("\nWrong Card Primary Account Number\n");goto Re_ENTER_PAN;}
    /********************************/



    /********   TERMINAL   ************/
    RE_Enter_Date: dateERROR = getTransactionDate(&terminalData);
    if(dateERROR == WRONG_DATE){puts("\nWrong Date Form\n");goto RE_Enter_Date;}

    dateERROR = isCardExpired(&cardData, &terminalData);
    if(dateERROR == EXPIRED_CARD){puts("\nExpired Card\n");return;}

    Re_Max_amount: amountERROR = setMaxAmount(&terminalData);
    if(amountERROR == INVALID_MAX_AMOUNT){puts("\nInvalid Maximum Amount\n");goto Re_Max_amount;}

    Re_Enter_amount: amountERROR = getTransactionAmount(&terminalData);
    if(amountERROR == INVALID_AMOUNT){puts("\nInvalid Amount\n");goto Re_Enter_amount;}

    amountERROR = isBelowMaxAmount(&terminalData);
    if(amountERROR == EXCEED_MAX_AMOUNT){puts("\nMaximum Amount Exceeded\n");goto Re_Enter_amount;}
    /********************************/



    /********   SERVER   ************/
    strcpy(transDATA.cardHolderData.cardExpirationDate , cardData.cardExpirationDate);
    strcpy(transDATA.cardHolderData.cardHolderName, cardData.cardHolderName);
    strcpy(transDATA.cardHolderData.primaryAccountNumber, cardData.primaryAccountNumber);

    transDATA.terminalData.maxTransAmount = terminalData.maxTransAmount;
    transDATA.terminalData.transAmount = terminalData.transAmount;
    strcpy(transDATA.terminalData.transactionDate, terminalData.transactionDate);

    transERROR = recieveTransactionData(&transDATA);
    switch (transERROR){
        case FRAUD_CARD:
            puts("\nFraud Card\n");return;
        case DECLINED_STOLEN_CARD:
            puts("\nDECLINED STOLEN CARD\n");return;
        case DECLINED_INSUFFECIENT_FUND:
            puts("\nDECLINED_INSUFFECIENT_FUND\n");return;
        case INTERNAL_SERVER_ERROR:
            puts("\nInternal Server Error\n");return;
        case APPROVED:
            break;
    }

    serverERROR = isValidAccount(&cardData,&accountRefrence);
    if(serverERROR == ACCOUNT_NOT_FOUND){printf("\nAccount Not Found\n");return;}

    serverERROR = isBlockedAccount(&accountRefrence);
    if(serverERROR == BLOCKED_ACCOUNT){puts("\nBlocked Account\n");}

    if(isAmountAvailable(&terminalData,&accountRefrence) == LOW_BALANCE){puts("\nDECLINED INSUFFECIENT FUND\n");};
    /********************************/

/*
    printf("\nTo Print a Transaction Enter 1\nTo Print all Transactions hit 2\nTo Quit Enter 3\n");
    scanf("%d",&temp);
    switch (temp){
        case 1:
            printf("\nEnter the Transaction Sequence Number\n");
            scanf("%d",&temp);
            prntTransData(temp);
            break;
        case 2:
            for(int i =0; i<255; i++){if(prntTransData(i) == -1){break;}}
            break;
        case 3:
            return;
    }
*/
}//end appStart


int main(void){


    appStart();
    return 1;
}




