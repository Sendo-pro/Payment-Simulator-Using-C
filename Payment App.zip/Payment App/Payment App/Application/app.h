#ifndef stdlib
    #include <stdlib.h>
#endif // stdlib

#ifndef stdio
    #include <stdio.h>
#endif // stdio

#ifndef string
    #include <string.h>
#endif // string

#ifndef card
    #include "../Card/card.h"
#endif // card

#ifndef terminal
    #include "../Terminal/terminal.h"
#endif // terminal

#ifndef server
    #include "../Server/server.h"
#endif // server

#ifndef app
    #define app
    void appStart(void);

#endif
